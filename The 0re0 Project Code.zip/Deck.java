import java.util.Random;
import java.util.Arrays;

public class Deck 
{
	private String[] cards = {"S1","S2","S3","S4","S5","S6","S7","S8","S9","S10","S11","S12","S13",
				"H1","H2","H3","H4","H5","H6","H7","H8","H9","H10","H11","H12","H13","BF","WF",
				"D1","D2","D3","D4","D5","D6","D7","D8","D9","D10","D11","D12","D13",
				"C1","C2","C3","C4","C5","C6","C7","C8","C9","C10","C11","C12","C13"};
	private String[] deck;	
	
	public boolean isEmpty ()
	{
		if(deck.length < 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}//checks if hand or deck is empty

	public String pop()
	{
		String card = deck[0];
		for(int i = 1; i < deck.length ; i++)
		{
			deck[i-1] = deck[i];
		}
		remove(card);
		return card;
	}//the most recent card that has been placed



	public void remove(String card){

		String[] array = this.deck.clone();

		int pos = -1;

		for(int i = 0; i < array.length ;i++){
			if(array[i].equals(card)){
				pos = i;
				break;
			}
		}

		String[] newArray = new String[array.length-1];

		for(int j = 0; j < newArray.length; j++){
			newArray[j] = array[j];
		}


		this.deck = newArray;

	}//removes a card from the deck
	
	
	public void ShuffleDeck ()
	{
		Random r = new Random();
		String[] deck = new String[cards.length];
			
		String[] halfA = new String[r.nextInt(11) + (cards.length)/2];
		for(int i = 0; i < halfA.length; i++)
		{
			halfA[i] = cards[i];
		}	
			
		String[] halfB = new String[cards.length - halfA.length];
		int count = 0;
		for(int t = halfA.length; t < cards.length; t++)
		{
			halfB[count] = cards[t];
			count++;
		}
		int countA = 0;
		int countB = 0;
		int norm = 0;
			
		while(norm < cards.length)
		{
			if(countA < halfA.length)
			{
				deck[norm] = halfA[countA];
				countA++;
				norm++;
			}
			if(countB < halfB.length)
			{
				deck[norm] = halfB[countB];
				countB++;
				norm++;
			}
		}
		
		int[] numdeck = clone(deck);
		
		if(Shannon(numdeck) < 5.00){
			ShuffleDeck(deck);
		}
		
	}//shuffles the deck
	
	public static int[] clone(String[] arr)
    {
        int[] ans = new int[arr.length];
        String n = "";
        for(int i = 0; i < arr.length; i++)
		{

			if(arr[i].equals("BF"))
			{
				ans[i] = 53;
			}
			else if(arr[i].equals("CF"))
			{
				ans[i] = 54;
			}
			else if(arr[i].substring(0,1).equals("S"))
			{
                n = arr[i].substring(1);
                ans[i] = Integer.parseInt(n);
            }
            else if(arr[i].substring(0,1).equals("H")){
                n = arr[i].substring(1);
                ans[i] = 13 + Integer.parseInt(n);
            }
            else if(arr[i].substring(0,1).equals("D")){
                n = arr[i].substring(1);
                ans[i] = 26 + Integer.parseInt(n);
            }
            else if(arr[i].substring(0,1).equals("C")){
				n = arr[i].substring(1);
                ans[i] = 39 + Integer.parseInt(n);
			}
        }
      return ans;
    }//converts the cards into numbers for a correct shannon
	
	public void ShuffleDeck (String[] cards)
	{
		String[] decks = new String[cards.length];
		Random r = new Random();
		
		String[] halfA = new String[r.nextInt(cards.length/4) + (cards.length)/2];
		for(int i = 0; i < halfA.length; i++)
		{
			halfA[i] = cards[i];
		}	
		
		String[] halfB = new String[cards.length - halfA.length];
		int count = 0;
		for(int t = halfA.length; t < cards.length; t++)
		{
			halfB[count] = cards[t];
			count++;
		}
		int countA = 0;
		int countB = 0;
		int norm = 0;
		
		while(norm < cards.length)
		{
			if(countA < halfA.length)
			{
				decks[norm] = halfA[countA];
				countA++;
				norm++;
			}
			if(countB < halfB.length)
			{
				decks[norm] = halfB[countB];
				countB++;
				norm++;
			}
		}
		int[] numdeck = clone(decks);
		
		if(numdeck.length == 54){
			if(Shannon(numdeck) >= 5.00)
			{
				ShuffleDeck(decks);
			}
		}
		this.deck = decks;
		
	}//shuffles deck
	
	private double Shannon (int[] ttt)
	{
		int[] diffs = new int[ttt.length];
		double shan = 0.0;
		
		for(int i = 0; i < ttt.length-1; i++)
		{
			int diff = ttt[i] - ttt[(i+1) % ttt.length];
			if(diff < 0)
			{
				diff += ttt.length;
			}
			diffs[diff]++;
		}
		for(int i = 0; i < ttt.length-1; i++)
		{
			double p = (double)diffs[i]/(double)ttt.length;
			if(p > 0.0)
			{
				shan -= p * Math.log(p) / Math.log(2);
			}
		}
		return shan;
	}//entropy
	
	public int getSize ()
	{
		int Size = deck.length;
		return Size;
	}//size of the deck

	public String toString(){
		return Arrays.toString(deck);
	}//toString
}