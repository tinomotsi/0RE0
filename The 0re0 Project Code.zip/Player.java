
public class Player{

	private String[] myArray;
	private boolean human;
	private int caught = -1;
	
	public Player(){ // Constructor of the player class
		myArray = new String[5];
		human = false; // Assumes that the player class is an AI player

		for(int i = 0; i < myArray.length ;i++){ // For loop to change all the null values to empty spaces
			if(myArray[i] == null){
				myArray[i] = "";
			}//
		}
	}//end of constructer

	public void setHuman(boolean b){ // public function enabling main program to set player object to human player/AI
		human = b;
	}

	public boolean isHuman(){ // Returns whether the player object is an AI or human player
		return human;
	}

	public void insert(String card){ // Function for when new card is entered for player's hand
		
		if(card.toUpperCase().equals("PICKUP")){ //IF the player decided to pickup a card, it must be ignored to not add "PICKUP" to player hand
		}else{
			String[] array = this.myArray.clone(); //Clones array
			int num = -1;
			boolean bigger = false;

			for(int i = 0; i < array.length; i++){

				if(array[i].equals("")){
					num = i;
					break;
				}
			}
			if(num == -1){
				bigger = true;
			}

			if(bigger == false){
				this.myArray[num] = card;
			}else{
				num = array.length;
				this.myArray = big(array);
				this.myArray[num] = card;
			}
		}
	}

	private String[] big(String[] array){
		String[] newArray = new String[array.length+1];

		for(int i = 0; i < array.length; i++){
			newArray[i] = array[i];
		}

		for(int j = 0; j < newArray.length ;j++){
			if(newArray[j] == null){
				newArray[j] = "";
			}
		}
		return newArray;
	}//makes discard pile bigger

	public void remove(String card){
		
		if(card.toUpperCase().equals("PICKUP")){
		}else{

			String[] array = this.myArray.clone();

			int pos = -1;

			for(int i = 0; i < array.length ;i++){
				if(array[i].equals(card)){
					pos = i;
					break;
				}
			}

			String temp = array[pos];
			array[pos] = array[array.length-1];
			array[array.length-1] = temp;

			String[] newArray = new String[array.length-1];

			for(int j = 0; j < newArray.length; j++){
				newArray[j] = array[j];
			}

			this.myArray = newArray;
		}
		
	}//removes cards from players hand (when player plays a card)
	public boolean isEmpty(){

		if(this.myArray.length == 0){
			return true;
		}

		return false;

	}//checks if players hands are empty
	private int bring(String card){

		Card num = new Card();

		return num.getRank(card);

	}//rank of cards
	private String[] highest(){

		String[] array = this.myArray.clone();
		int[] ranks = new int[array.length];

		//Assigns ranks of cards to the different arrays

		for(int k = 0; k < array.length;k++){
			int high = bring(array[k]);
			ranks[k] = high;
		}


		//Bubblesorts the arrays

		int num = ranks.length;

    	for (int i = 0; i < num-1; i++){     
    		for (int j = 0; j < num-i-1; j++){ 
        		if (ranks[j] > ranks[j+1]){  // sorts card according to ranks

        			String temp = array[j];  
    				array[j] = array[j+1];  
   				 	array[j+1] = temp;

				}
			}
		}

		return array;

	}

	public int getHandsize(){
		return this.myArray.length;

	}
	public int getPoints(){



		int[] points = {50,10,10,10,10,9,40,14,6,5,4,3,25,11};
		String[] point = {"F","13","12","11","10","9","8","7","6","5","4","3","2","1"};
		String[] array = this.myArray.clone();
		int total = 0;

		for(int i = 0; i < array.length; i++){
			String word = array[i]; // finds word

			if(!(word.equals(""))){
				String compare = word.substring(1); // finds string with rank possesion

				for(int j = 0; j < point.length; j++){
					if(compare.equals(point[j])){
						total += points[j];
					}
				}
			}

		}
		if(total == 0){
			if(this.myArray.length > 0){
				return -1;
			}
		}

		return total;
		
	}
	public boolean getA(){//position of A (use this when a joker or 2 is played)

		String[] array = this.myArray.clone();

		for(int i = 0; i < array.length; i++){

			String word = array[i]; // finds word
			String compare = word.substring(1); // finds string with rank possesion

			if(compare.equals("1")){
				return true;
			}

		}
		return false;	
	}

	public String[] getHand(){

		return this.myArray;

	}

	public String findA(){//finds the Ace

		String[] array = this.myArray.clone();

		for(int i = 0; i < array.length; i++){

			String word = this.myArray[i]; // finds word
			String compare = word.substring(1); // finds string with rank possesion

			if(compare.equals("1")){
				return word;
			}
		}
		return "";
	}

	public String playpick(){ //is only for the tw0 card and the joker

		//If the player is told to pick up cards

			if(getA()){
				return findA(); // returns the ACE that has been found
			}else{
				return "GIVE";
			}

	}

	public String play(String played,String suit){ // Class made for player AI

		Rubish rubbish = new Rubish(); // Class needed for rule validation
		
		
		//Playing on a normal hand and reacting to an 8 card

		String[] plays = highest();

		for(int i = 0; i < plays.length; i++){

			if(played.substring(1).equals("8")){ //Reacting to a previously played card
				if(rubbish.is8Valid(plays[i],played,suit)){
					return plays[i];
				}
				
			}else{
				if(rubbish.isValid(plays[i],played)){ // Checks to see if card can be played
					return plays[i];
				}
			}
		}

		return "PICKUP"; // And if no other card can be played pick up 1
	}

	public String suit8(String card){

			if(most().equals("")){
				return card.substring(0,1); // Returns the 8 card suit,because for this condition to be met, the only card left is a JOKER, and that can be played on any card
			}

			return most(); //Returns most frequent suit

	}
	public boolean hasCard(String played){

		String[] array = this.myArray.clone();
		
		if(played.equals("PICKUP")){
			return true;
		}
		
		for(int i = 0; i < array.length; i++){
			if(played.equals(array[i])){
				return true;
			}
		}

		return false;
	}//checks if you are able to play

	private String most(){

		int[] counter = new int[4];
		String[] suits = {"S","H","D","C"};

		//Counts suits in the array

		for(int i = 0; i < this.myArray.length; i++){

			String word = this.myArray[i];
			String compare = word.substring(0,1);

			if(word.substring(1).equals("F")){

			}else{

				if(compare.equals("S")){
					counter[0]++;

				}else if(compare.equals("H")){
					counter[1]++;

				}else if(compare.equals("D")){
					counter[2]++;	

				}else if(compare.equals("C")){
					counter[3]++;	
				}

			}	
		}

		//Checks to see which suit is the most

		int ihigh = 0;

		for(int j = 0; j < counter.length; j++){
			if(counter[j] > counter[ihigh]){
				ihigh = j;
			}
		}

		// If no other suits are found then it must be a joker AKA "F"
		if(counter[ihigh] == 0){
			return "";
		}

		return suits[ihigh];

	}//counts suits and decides which is most suitable to play(AI)
}