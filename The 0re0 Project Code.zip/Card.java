import java.util.Random;
import java.util.Arrays; 
import java.util.Scanner;

public class Card
{ 
	private String[] deck;
	private String[] showdeck;
	
	public Card(){
		String[] deck = {"S1","S2","S3","S4","S5","S6","S7","S8","S9","S10","S11","S12","S13",
				"H1","H2","H3","H4","H5","H6","H7","H8","H9","H10","H11","H12","H13","BF","WF",
				"D1","D2","D3","D4","D5","D6","D7","D8","D9","D10","D11","D12","D13",
				"C1","C2","C3","C4","C5","C6","C7","C8","C9","C10","C11","C12","C13"};
							 
		showdeck = new String[54];
	}
	
	public int getRank(String c){
		if(c.substring(1).equals("8")){
			return 3;
		}
		else if(c.substring(1).equals("F") || c.substring(1).equals("2")){
			return 2;
		} 
		else if(c.substring(1).equals("13") || c.substring(1).equals("11") || c.substring(1).equals("7")){
			return 1;
		}
		else{
			return 0;
		}
	}	//ranks for the ai (higher the int, the more important).
	
	public String getString(String c){
		if(c.substring(0,2).equals("S")){
			return "SPADES";
		}
		else if(c.substring(0,2).equals("H")){
			return "HEARTS";
		}
		else if(c.substring(0,2).equals("D")){
			return "DIAMONDS";
		}
		else if(c.substring(0,2).equals("C")){
			return "CLUBS";
		}
		else if(c.substring(1).equals("F")){
			return "JOKER";
		}
		else{
			return "INVALID CARD";
		}
	}
	
	public String setSuit(){
		Scanner sc = new Scanner(System.in);
		System.out.print("Please enter valid suit to change to <>: ");
		String user = sc.nextLine();
		while(!(user.equals("") & user.equals("") & user.equals("") & user.equals(""))){
			System.out.print("Please enter valid suit <>: ");
			user = sc.nextLine();
		}
		return user;
	}	//sets the suit 
	
	public String[] toStringArr (String[] arr) {	//couldnt get the input for the users to be correct
		
		String[] show = new String[arr.length];
		
		for(int i = 0; i < arr.length; i++){
			if(arr[i].substring(0,1).equals("S")){
			arr[i] = "A" + arr[i].substring(1);}
			else if(arr[i].substring(0,1).equals("H")){
			arr[i] = "B" + arr[i].substring(1);}
			else if(arr[i].substring(0,1).equals("D")){
			arr[i] = "C" + arr[i].substring(1);}
			else if(arr[i].substring(0,1).equals("S")){
			arr[i] = "D" + arr[i].substring(1);}
			else if(arr[i].equals("WF")){
				arr[i] = "CF";}
		}
		
		for(int i = 0; i < arr.length; i++){
			if(arr[i].length() > 2 && arr[i].substring(2).equals("0")){
				show[i] = arr[i].substring(0,1) + "A";
			}
			else if(arr[i].length() > 2 && arr[i].substring(2).equals("1")){
				show[i] = arr[i].substring(0,1) + "B";
			}
			else if(arr[i].length() > 2 && arr[i].substring(2).equals("2")){
				show[i] = arr[i].substring(0,1) + "D";
			}
			else if(arr[i].length() > 2 && arr[i].substring(2).equals("3")){
				show[i] = arr[i].substring(0,1) + "E";
			}
			
			int c = Integer.parseInt("DC" + arr[i],16);
			show[i] = "\uD83C" + (char) c;
		}
		
		
		return show;
		
    } //toString
}