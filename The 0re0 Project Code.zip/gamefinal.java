import java.util.Scanner;
import java.util.Arrays;
import java.io.File;
import java.io.FileNotFoundException;



public class gamefinal{//where rules and game is put together
	public static void main(String[] args){
		Deck deck = new Deck();
		Card vision = new Card();
		Rubish rubbish = new Rubish();
		int pcount=0;
		int check=0;
		Scanner sc = new Scanner(System.in);
		
		deck.ShuffleDeck();
			
		Player player1= new Player();
		Player player2= new Player();
		Player player3= new Player();
		Player player4= new Player();
		
		help();
		
		
		while (true){// Asks how many players are playing
			System.out.print("-------------------\nENTER human players: ");
			pcount = sc.nextInt();
			System.out.print("-------------------\nENTER AI players: ");
			int aicount = sc.nextInt();
			check = pcount + aicount;
			if ((check>4) | (check<2)){
				System.out.println("Invalid amount of players. Total amount of players cannot exceed 4.");
			}else{break;}
		}
		Player[] players= {player1,player2,player3,player4};
		// Setting players to either human or AI
		
		for(int i=0;i<pcount;i++){
			players[i].setHuman(true);
		}
		
		//Deal the player cards
		
		for(int j = 0; j < check; j++){
			for(int k = 0; k < 5;k++){
				players[j].insert(deck.pop());
			}
		}
		
		rubbish.rubArr(deck.pop());
		
		String change = "";
		boolean endgame = false;
		int winner = -1;
		while(true){ // Continues game until broken
			
			for(int x = 0; x < check ; x++){
				for(int p = 0; p < check; p++){ // Checks if players' hand is empty
							if(players[p].isEmpty()){
								endgame = true;
								winner = p;
								break;	
							}
						}
						if(endgame == true){ // End of game,breaking out of while loop	
							break;	
						}
				
				if(players[x].isHuman()){ // For any human players
					
					while(true){
						Scanner psc = new Scanner(System.in);
						System.out.print("_______________\n");
						System.out.println("PLAYER "+ (x+1) +"'S TURN\n_______________");
						System.out.println("\nCurrently on table: \n--------" + rubbish.showPop() + "--------");//
						System.out.println("........................");
						System.out.println("      Your hand:");
						System.out.println(Arrays.toString(players[x].getHand()));
						System.out.println("........................");
						System.out.print("ENTER CARD: ");
						String play = psc.nextLine();
						play = play.toUpperCase();
						
						if(players[x].hasCard(play)){//mainly to check if your card is in your hand or not

							if(rubbish.isValid(play,rubbish.showPop()) == true || rubbish.is8Valid(play,rubbish.showPop(),change) == true){//checks if valid 
								
								if(play.toUpperCase().equals("PICKUP")){
									pickup(players[x],deck,rubbish,1);
								}
								else{
									players[x].remove(play);
									rubbish.rubArr(play);
								}

								if(play.substring(1).equals("2")){
									if(players[convert(x+1,check)].getA() && players[convert(x+1,check)].isHuman()){
										System.out.println("Player "+(dspConvert(x+2,check))+" do you want to play an Ace <Y> for yes, else any other letter for no");
										String decide = psc.nextLine().toUpperCase();
										
										if(decide.equals("Y")){
											String a = players[convert(x+1,check)].findA();
											players[convert(x+1,check)].remove(a);
											rubbish.rubArr(a);
											x++;

										}else{
											pickup(players[convert(x+1,check)],deck,rubbish,2);
											System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 2 Cards");
											x++;	
											}
									}
									else if(!(players[convert(x+1,check)].isHuman())){
										
										String decide = players[convert(x+1,check)].playpick(); // Decision based on AI

										if(decide.equals("GIVE")){ // Player has decided to pickup
											pickup(players[convert(x+1,check)],deck,rubbish,2);
											System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 2 Cards");
										}else{
											System.out.println("ACE PLAYED: "+decide);
											players[convert(x+1,check)].remove(decide); // Removes ACE from player hand
											rubbish.rubArr(decide); //Adds to rubbish pile
										}
										x++;
									}
									else{ // For is human player did not have an ACE
										pickup(players[convert(x+1,check)],deck,rubbish,2);
										System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 2 Cards");
										x++;	
									}
									
								}else if(play.substring(1).equals("F")){
									if(players[convert(x+1,check)].getA() && players[convert(x+1,check)].isHuman()){
										System.out.println("\nPlayer "+(dspConvert(x+2,check))+" do you want to play an Ace <Y> for yes, else any other letter for no");
										String decide = psc.nextLine().toUpperCase();
										
										if(decide.equals("Y")){
											String a = players[convert(x+1,check)].findA();
											players[convert(x+1,check)].remove(a);
											rubbish.rubArr(a);
											x++;
											
										}else{
											pickup(players[convert(x+1,check)],deck,rubbish,5);
											System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 5 Cards");
											x++;	
										}
									}
									else if(!(players[convert(x+1,check)].isHuman())){
										
										String decide = players[convert(x+1,check)].playpick(); // Decision based on AI

										if(decide.equals("GIVE")){ // Player has decided to pickup
											pickup(players[convert(x+1,check)],deck,rubbish,5);
											System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 5 Cards");
										}else{
											System.out.println("ACE PLAYED: "+decide);
											players[convert(x+1,check)].remove(decide); // Removes ACE from player hand
											rubbish.rubArr(decide); //Adds to rubbish pile
										}
										x++;
									}
									else{
										pickup(players[convert(x+1,check)],deck,rubbish,5);
										System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 5 Cards");
										x++;	
									}
									
								}else if(play.substring(1).equals("13")){
									System.out.println("\n!Player " + (x+1) + " wants to play again!");//
									int loop = convert(x-1,check);
									x = loop;
									
								}else if(play.substring(1).equals("11")){
									System.out.println("\nPlayer " + (x+1) + " has reversed!");//
									int loop = x-1;
									if(check > 2){
										loop = convert(loop-1,check);
									}
									x = loop;
									
									
								}else if(play.substring(1).equals("7")){
									int loop = x;
									System.out.println("\nPlayer " + (x+1) + " has skipped you!");//
									if(check > 2){
										loop = convert(x+1,check);
									}
									else{
										if(x == 1){
											loop = 2;
										}
										else{
											loop = 1;
										}
									}
									x = loop;
									
								}else if(play.substring(1).equals("8")){
									while(true){
										System.out.println("\nWhich suit would you like to change to? <D> <H> <C> or <S>");
										change = psc.nextLine().toUpperCase();
										if(change.equals("D")||change.equals("H")||change.equals("C")||change.equals("S")){
											break;
										}
										else{
											System.out.println("\n........................");
											System.out.println("Please choose a valid suit");
											System.out.println("........................\n");
											}
									}	
									
								}
								
								break;
							}
							System.out.println("\n........................");
							System.out.println("Please make a valid move");
							System.out.println("\n........................");
						}
						else{
							System.out.println("\n................................");
							System.out.println("Please enter a card in your deck");
							System.out.println("................................\n");}
					}
					
				}else{// For AI players

					String playCard = rubbish.showPop();//Shows last that was played

					System.out.println("Player "+Integer.toString(x+1)+"'s cards  "+Arrays.toString(players[x].getHand()));

					String played = players[x].play(playCard,change); // The card the player decided to play
					String power = played.substring(1);// Checking power cards


					if(played.equals("PICKUP")){   // It's either player picks up a card or plays one
						pickup(players[x],deck,rubbish,1);
						System.out.println("Player "+(dspConvert(x+1,check))+" has picked up");
						continue;//Continues to next player
					}else{
						System.out.println("PLAYED CARD: "+played);
						players[x].remove(played);  // The card has been played
						rubbish.rubArr(played,-1);
					}

					//If any power cards were played then action is taken here

					String decide = "";
					int loop = check; // Equal to number of players for logic reasons

					if(power.equals("2")){ // TWO card played must pick up 2 or play ACE

						decide = players[convert(x+1,check)].playpick(); // Decision based on AI

						if(decide.equals("GIVE")){ // Player has decided to pickup
							pickup(players[convert(x+1,check)],deck,rubbish,2);
							System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 2 Cards");
							
						}else{
							System.out.println("ACE PLAYED: "+decide);
							players[convert(x+1,check)].remove(decide); // Removes ACE from player hand
							rubbish.rubArr(decide,-1); //Adds to rubbish pile
						}

						loop = x;
						loop++; // Skips the next player as next players turn is forfeited, e.g from player 1 to player 3 in next turn
						
					}else if(power.equals("F")){ // JOKER played must pick up 5 or play ACE

						decide = players[convert(x+1,check)].playpick(); // Decision based on AI

						if(decide.equals("GIVE")){ // Player has decided to pickup
							pickup(players[convert(x+1,check)],deck,rubbish,5);
							System.out.println("Player "+(dspConvert(x+2,check))+" has picked up 5 Cards");
						}else{
							System.out.println("ACE PLAYED: "+decide);
							players[convert(x+1,check)].remove(decide); // Removes ACE from player hand
							rubbish.rubArr(decide,-1); //Adds to rubbish pile
						}

						loop = x;
						loop++; // Skips the next player as next players turn is forfeited, e.g from player 1 to player 3 in next turn

							
					}else if(power.equals("8")){
						
						change = players[x].suit8(played);
						System.out.println("Player "+dspConvert(x+1,check)+" has changed suit to "+change);
						loop = x; // Keeps the flow of the players normal
						
					}else if(power.equals("11")){
						loop = x;
						loop--;
						loop--;// Reverses player, one back. e.g from player 2 to player 1 in next turn
						System.out.println("Player "+dspConvert(x+1,check)+" has reversed play");
	
					}else if(power.equals("7")){
						loop = x;
						loop++; // Skips the next player, e.g from player 1 to player 3 in next turn
						System.out.println("Player "+dspConvert(x+1,check)+" has skipped you");

							
					}else if(power.equals("13")){
						loop = x;
						loop--; // Allows the player to play again, e.g. from player 1 to player 1
						System.out.println("Player "+dspConvert(x+1,check)+" has second play");

					}else{
						loop = x; // Keeps the flow of the players normal
					}

					x = convert(loop,check);

				}//End of AI segment
				

			}//End of For loop

			if(endgame == true){ // End of game,breaking out of while loop	

				break;	
			}
		
		}//End of while loop

		System.out.println("PLAYER " + (winner+1) + " is the WINNER!\n\n"); // Displays winner
		

		points(players,check);


		
		
	}
	public static void pickup(Player p, Deck d,Rubish r, int cards){//picks up card
		
		if(cards <= d.getSize()){//deck size has to be bigger than pickup for you to pop or pickup
			for(int i = 0; i < cards; i++){
				p.insert(d.pop());
			}
		}else{//else if takes discard pile and shuffles but leaves most recent card
			d.ShuffleDeck(r.getDeck());
			String temp = r.showPop();
			r.clear();
			r.rubArr(temp);
			System.out.println(d.toString());
			pickup(p,d,r,cards);	
		}
	}
	public static int convert(int num, int players){
		int total = 0;
		
		if(num>=0){
			total = num % players;
		}
		else{
			total = players + num;
		}
		return total ;	
	}//converter when using skip, add, reverse ect
	
	public static int dspConvert(int num, int players){
		int total = 0;
		
		if(num < 1){
			total = players;
		}
		else if(num > players){
			total = 1;
		}
		else{
			total = num;
		}
		return total;
	}//converter for display
	
	public static void points(Player[] players, int numPlayers){

		String[] array = {"Player1 - ","Player2 - ","Player3 - ","Player4 - "};
		int[] ranks = new int[4];

		//Assigns points of cards to the different arrays

		for(int k = 0; k < ranks.length;k++){
			int high = players[k].getPoints();
			ranks[k] = high;
		}

		//Bubblesorts the arrays, sorts the arrays from smallest to biggest

		int num = ranks.length;

    	for (int i = 0; i < num-1; i++){     
    		for (int j = 0; j < num-i-1; j++){ 
        		if (ranks[j] > ranks[j+1]){  // sorts players according to points

        			String temp = array[j];  //Whenever the players array is swapped and sorted..... 
    				array[j] = array[j+1];  
   				 	array[j+1] = temp;

   				 	int temp2 = ranks[j];  //...the ranks array is swapped and sorted the same
    				ranks[j] = ranks[j+1];  
   				 	ranks[j+1] = temp2;
				}
			}
		}

		//Displaying the places

		int pos=0;
		String[] positions={"1st: ","2nd: ","3rd: ","4th: "};

		for(int l = 0; l < 4; l++){

			if(ranks[l] == -1){
			
			}else{
				System.out.println(positions[pos]+ array[l] + ranks[l] + " points");
				pos++;
			}

			if(pos >= numPlayers){
				break;
			}
		}
		
 
	}
	public static void help(){//file that explains how to play(should print at the top when program runs)

		String filename = "Help.txt";
		String txt = "";


		File myFile = new File(filename);
	  
		try{

		   Scanner input = new Scanner(myFile);
		   while(input.hasNextLine()){            
					   txt += input.nextLine() +"\n";
				
			}
			input.close();
			System.out.println(txt);   
		   
		   }catch (FileNotFoundException e){
				e.printStackTrace();
				System.out.println("Help is not available");
	  
		   }

	}
}