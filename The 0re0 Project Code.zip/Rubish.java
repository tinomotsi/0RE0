import java.util.Arrays;
public class Rubish{
	
	private String[] rub_deck;
	
	public Rubish(){
		rub_deck = new String[1];

		for(int i = 0; i < rub_deck.length ;i++){
			if(rub_deck[i] == null){
				rub_deck[i] = "";
			}
		}
		
	}//creats a discard pile
	
	public String showPop(){
		int pos = 0;
		while(pos < this.rub_deck.length && !(this.rub_deck[pos].equals(""))){
			pos++;
		}
		return this.rub_deck[pos-1];
	}//most recent card on the discard pile
	
	public boolean isValid(String c,String pop){
		if(c.toUpperCase().equals("PICKUP")){
			return true;
		}
		else if(c.substring(1).equals("8")){
			rubArr(c);
			showPop();
			return true;
		}
		else if(c.substring(1).equals("F")){
			rubArr(c);
			showPop();
			return true;
		}
		else if(pop.substring(1).equals("F")){
			rubArr(c);
			showPop();
			return true;
		}
		else if(c.substring(1).equals(pop.substring(1))){
			rubArr(c);
			showPop();
			return true;
		}
		else if(c.substring(0,1).equals(pop.substring(0,1))){
			rubArr(c);
			showPop();
			return true;
		}
		else{
			return false;
		}
	}//checks if card is able to be played
	
	public boolean is8Valid(String c,String pop,String suit){
		if(pop.substring(1).equals("8") & c.substring(0,1).equals(suit)) {
			return true;
		}
		else if(pop.substring(1).equals("F")){
			return true;
		}else{
			return false;
		}
	}//checks rules when playing 8 card
	
	public void rubArr(String c){
		
			String[] array = this.rub_deck.clone();
			int num = -1;
			boolean bigger = false;

			for(int i = 0; i < array.length; i++){

				if(array[i].equals("")){
					num = i;
					break;
				}
			}
			if(num == -1){
				bigger = true;
			}

			if(bigger == false){
				this.rub_deck[num] = c;
			}else{
				num = array.length;
				this.rub_deck = big(array);
	
			}
		}//discard pile that stores cards that have been played
	public void rubArr(String c,int u){
		
			String[] array = this.rub_deck.clone();
			int num = -1;
			boolean bigger = false;

			for(int i = 0; i < array.length; i++){

				if(array[i].equals("")){
					num = i;
					break;
				}
			}
			if(num == -1){
				bigger = true;
			}

			if(bigger == false){
				this.rub_deck[num] = c;
			}else{
				num = array.length;
				this.rub_deck = big(array);
				this.rub_deck[num] = c;
			}
		}//checks if discard pile is big enough
	private String[] big(String[] array){
		String[] newArray = new String[array.length+1];

		for(int i = 0; i < array.length; i++){
			newArray[i] = array[i];
		}
		
		newArray[newArray.length-1] = "";
		return newArray;
	}//makes discard pile bigger
	
	public String[] getDeck(){
		return this.rub_deck;
	}
	public String content(){
		return Arrays.toString(this.rub_deck);
	}
	
	public void clear(){
		this.rub_deck = new String[1];

		for(int i = 0; i < this.rub_deck.length ;i++){
			if(this.rub_deck[i] == null){
				this.rub_deck[i] = "";
			}
		}
	}//clears the discard pile so you can re-shuffle
	
}